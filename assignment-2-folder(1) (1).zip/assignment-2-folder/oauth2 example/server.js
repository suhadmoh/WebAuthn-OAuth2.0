const express = require('express');
const querystring = require('querystring');
const secret = require('./client_secret.json');
const app = express();

const PORT =  process.env.PORT || 3000;

const CLIENT_ID = secret.client_id
const CLIENT_SECRET = secret.client_secret
const REDIRECT_URI = 'http://localhost:3000/auth/google/callback';


// getting the authorization code from google
app.get('/auth/google', (req, res) => {
    const authorizationUrl = 'https://accounts.google.com/o/oauth2/v2/auth';
    const params = {
        client_id: CLIENT_ID,
        redirect_uri: REDIRECT_URI,
        response_type: 'code',
        scope: 'https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email',  // Updated scope
        access_type: 'online'
    };
    res.redirect(`${authorizationUrl}?${querystring.stringify(params)}`);
});

// exchanging the authorization code and then using it to get the access token
// and then using the access token to get the user's email address
app.get('/auth/google/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) {
        return res.status(400).send('Authorization code is missing');
    }
    try {
        const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: querystring.stringify({
                code,
                client_id: CLIENT_ID,
                client_secret: CLIENT_SECRET,
                redirect_uri: REDIRECT_URI,
                grant_type: 'authorization_code'
            })
        });

        if (!tokenResponse.ok) {
            throw new Error('Failed to exchange authorization code for access token');
        }

        const tokenData = await tokenResponse.json();
        const accessToken = tokenData.access_token;

        if (!accessToken) {
            throw new Error('Access token is missing in the response');
        }

        const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v1/userinfo', {
            headers: { Authorization: `Bearer ${accessToken}` }
        });

        if (!userInfoResponse.ok) {
            throw new Error('Failed to fetch user info');
        }

        const userData = await userInfoResponse.json();
        // send Login successful
        res.send(`
            <h1>Login successful</h1>
            <p>Welcome ${userData.email}</p>
        `);
        
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});




app.use(express.static('public'));

app.listen(PORT, () => {
    console.log('Server is running on http://localhost:3000');
});



