document.getElementById('loginButton').addEventListener('click', () => {
    window.location.href = '/auth/google';
});